from flask import Flask, render_template
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad

app = Flask(__name__)

def encrypt_data(data, key):
    cipher = AES.new(key, AES.MODE_CBC)
    ct_bytes = cipher.encrypt(pad(data.encode('utf-8'), AES.block_size))
    iv = cipher.iv
    encrypted_data = iv + ct_bytes
    return encrypted_data

@app.route('/')
def index():
    key = get_random_bytes(16)
    with open("C:\\Users\\vaibh_e47rn93\\dataprivacy\\Front_dashboard\\WebsiteTemplate\\guarder-html\\templates\\Accident_reports.html", "r", encoding="utf-8") as file:
        html_data = file.read()
    encrypted_html_data = encrypt_data(html_data, key)
    return render_template("C:\\Users\\vaibh_e47rn93\\dataprivacy\\Front_dashboard\\WebsiteTemplate\\guarder-html\\index1.html", encrypted_html_data=encrypted_html_data.decode('latin-1'))

if __name__ == '__main__':
    app.run(debug=True)
